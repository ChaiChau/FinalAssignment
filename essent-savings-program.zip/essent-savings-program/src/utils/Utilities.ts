import { Response } from 'express';

/**
 * Send a standardized error response.
 * @param {Response} res - The express response object.
 * @param {number} statusCode - The HTTP status code to send.
 * @param {string} message - The error message to send.
 */
export function sendErrorResponse(res: Response, statusCode: number, message: string) {
    res.status(statusCode).send({ error: message });
}

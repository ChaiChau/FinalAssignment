import { Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { productList } from '../datastore';
import { Product } from '../models/products';
import { sendErrorResponse } from '../utils/Utilities';

export const filtertProductById = (productId: string): Product | undefined =>
  // eslint-disable-next-line implicit-arrow-linebreak
  productList.find((product) => product.id === productId);

export const getAllProducts = (req: Request, res: Response) => {
  try {
    const simulatedDay = Number(req.get('Simulated-Day'));

    const updatedProducts = productList.map((prod) => {
      let soldStock = 0;
      prod.saleDays.forEach((day) => {
        if (day <= simulatedDay) {
          soldStock += 1;
        }
      });

      return {
        ...prod,
        stock: prod.stock - soldStock,
      };
    });

    return res.status(200).json(updatedProducts);
  } catch (error) {
    return sendErrorResponse(res, 500, 'Internal Server Error');
  }
};

export const getProductById = (req: Request, res: Response) => {
  try {
    const { productId } = req.params;
    const product = productList.find((p) => p.id === productId);

    if (!product) {
      return sendErrorResponse(res, 404, 'Product not found');
    }

    let soldStock = 0;
    product.saleDays.forEach((day) => {
      if (day <= Number(req.get('Simulated-Day'))) {
        soldStock += 1;
      }
    });

    const updatedProduct = {
      ...product,
      stock: product.stock - soldStock,
    };

    return res.status(200).json(updatedProduct);
  } catch (error) {
    return sendErrorResponse(res, 500, 'Internal Server Error');
  }
};

export const addProduct = (req: Request, res: Response) => {
  try {
    // eslint-disable-next-line object-curly-newline
    const { title, description, price, stock } = req.body;

    // Basic validation
    if (!title || !description || !price || !stock) {
      return sendErrorResponse(res, 400, 'Missing required product details');
    }

    // Check if product already exists
    const existingProduct = productList.find((p) => p.title === title);
    if (existingProduct) {
      return sendErrorResponse(res, 400, 'Product already exists');
    }

    // Create a new product
    const newProduct: Product = {
      id: uuidv4(),
      title,
      description,
      price,
      stock,
      saleDays: [],
    };

    productList.push(newProduct);

    return res.status(201).json(newProduct);
  } catch (error) {
    return sendErrorResponse(res, 500, 'Internal Server Error');
  }
};

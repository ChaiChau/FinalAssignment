import { Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { cloneDeep } from 'lodash';
import { accounts } from '../datastore';
import { Account } from '../models/account';
import { sendErrorResponse } from '../utils/Utilities';
import { filtertProductById } from './ProductController';

export const createAccount = (req: Request, res: Response) => {
  try {
    const { name } = req.body;

    // Validate name format
    const nameRegex = /^[A-Za-z]+$/;
    if (!name || !nameRegex.test(name)) {
      return sendErrorResponse(res, 400, 'Invalid name format');
    }

    // Create and store the new account
    const newAccount: Account = {
      id: uuidv4(),
      name,
      balance: 0,
      deposits: [],
      purchase: { totalPurchaseCost: 0 },
    };
    accounts.push(newAccount);

    return res.status(200).json({
      id: newAccount.id,
      name: newAccount.name,
      balance: newAccount.balance,
    });
  } catch (error) {
    return sendErrorResponse(res, 500, 'Internal Server Error');
  }
};

export const getAllAccounts = (req: Request, res: Response) => {
  try {
    const simulatedDay = Number(req.get('Simulated-Day'));
    const updatedAccounts: Account[] = cloneDeep(accounts);

    updatedAccounts.forEach((acc) => {
      if (simulatedDay >= 30) {
        const annualInterestRate = 0.08; // 8% annual interest
        const dailyInterestRate = annualInterestRate / 365;
        acc.balance += Number(
          // eslint-disable-next-line @typescript-eslint/comma-dangle
          (dailyInterestRate * 30 * acc.balance).toFixed(2)
        );
      }
      delete acc.deposits;
      delete acc.purchase;
    });

    return res.status(201).json(updatedAccounts);
  } catch (error) {
    return sendErrorResponse(res, 500, 'Internal Server Error');
  }
};

export const getAccountById = (req: Request, res: Response) => {
  try {
    const { accountId } = req.params;
    const simulatedDay = Number(req.get('Simulated-Day'));
    const account = accounts.find((acc) => acc.id === accountId);

    if (!account) {
      return sendErrorResponse(res, 404, 'Account not found');
    }

    // Using cloneDeep to create a deep copy of the account
    const accountCopy: Account = cloneDeep(account);

    // Add interest calculation here if applicable
    if (simulatedDay % 30 === 0) {
      const annualInterestRate = 0.08; // 8% annual interest
      const dailyInterestRate = annualInterestRate / 365;
      accountCopy.balance += dailyInterestRate * 30 * accountCopy.balance;
    }

    // Remove sensitive or unnecessary information
    delete accountCopy.deposits;
    delete accountCopy.purchase;

    return res.status(200).json(accountCopy);
  } catch (error) {
    return sendErrorResponse(res, 500, 'Internal Server Error');
  }
};

export const registerDeposit = (req: Request, res: Response) => {
  try {
    const { accountId } = req.params;
    const { amount } = req.body;
    const depositDay = Number(req.get('Simulated-Day'));

    const account = accounts.find((acc) => acc.id === accountId);
    if (!account) {
      return sendErrorResponse(res, 404, 'Account not found');
    }

    // Basic validation
    if (typeof amount !== 'number' || amount <= 0) {
      return sendErrorResponse(res, 400, 'Invalid deposit amount');
    }

    if (typeof depositDay !== 'number' || depositDay < 0) {
      return sendErrorResponse(res, 400, 'Invalid deposit day');
    }

    const newDeposit = {
      depositId: uuidv4(),
      depositDay,
      amount,
    };

    account.deposits.push(newDeposit);
    account.balance += amount;

    return res.status(201).json(newDeposit);
  } catch (error) {
    return sendErrorResponse(res, 500, 'Internal Server Error');
  }
};

export const registerPurchase = (req: Request, res: Response) => {
  try {
    const { accountId } = req.params;
    const { productId } = req.body;
    const purchaseDay = Number(req.get('Simulated-Day'));

    const account: Account | undefined = accounts.find(
      // eslint-disable-next-line @typescript-eslint/comma-dangle
      (acc) => acc.id === accountId
    );
    if (!account) {
      return sendErrorResponse(res, 404, '');
    }

    const product = filtertProductById(productId);
    if (!product) {
      return sendErrorResponse(res, 404, '');
    }

    if (typeof purchaseDay !== 'number' || purchaseDay < 0) {
      return sendErrorResponse(res, 400, '');
    }

    if (account.balance < product.price) {
      return sendErrorResponse(res, 400, '');
    }

    account.balance -= product.price;
    if (!account.purchase) {
      account.purchase = { totalPurchaseCost: 0, lastPurchaseDay: 0 };
    }
    account.purchase.totalPurchaseCost += product.price;
    account.purchase.lastPurchaseDay = purchaseDay;

    product.stock -= 1;

    return res.status(200).send({ message: 'Purchase successful' });
  } catch (error) {
    return sendErrorResponse(res, 500, 'Internal Server Error');
  }
};

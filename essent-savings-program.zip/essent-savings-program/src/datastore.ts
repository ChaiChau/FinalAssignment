import { cloneDeep } from 'lodash';
import { Account } from './models/account';
import products, { Product } from './models/products';

export const accounts: Account[] = [];
export const productList: Product[] = cloneDeep(products);
